/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as React from "react";
import { useState, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Camera, 
  Sparkles, 
  TrendingUp, 
  DollarSign, 
  Zap, 
  Share2, 
  ArrowRight,
  ShieldCheck,
  Smartphone,
  CheckCircle2,
  X,
  RefreshCw,
  Image as LucideImage
} from "lucide-react";
import { GoogleGenAI } from "@google/genai";

// Initialization
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

type View = "business_pitch" | "demo" | "results";

interface VibeResult {
  score: number;
  aesthetic: string;
  tips: string[];
  trendingSound: string;
  suggestedAddOn: string;
}

export default function App() {
  const [view, setView] = useState<View>("business_pitch");
  const [loading, setLoading] = useState(false);
  const [image, setImage] = useState<string | null>(null);
  const [result, setResult] = useState<VibeResult | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const performVibeCheck = async (imgData: string) => {
    setLoading(true);
    try {
      const base64Data = imgData.split(',')[1];
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [
          {
            parts: [
              { text: "Analyze the aesthetic and 'vibe' of this image. Provide a Vibe Score (0-100), the aesthetic name (e.g., Y2K, Quiet Luxury, Streetwear, Minimalism), 3 styling/improvement tips, a trending TikTok sound category that matches, and 1 specific accessory or item that would complete this vibe." },
              { inlineData: { data: base64Data, mimeType: "image/jpeg" } }
            ]
          }
        ],
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: "object",
            properties: {
              score: { type: "number" },
              aesthetic: { type: "string" },
              tips: { type: "array", items: { type: "string" } },
              trendingSound: { type: "string" },
              suggestedAddOn: { type: "string" }
            },
            required: ["score", "aesthetic", "tips", "trendingSound", "suggestedAddOn"]
          }
        }
      });

      const data = JSON.parse(response.text || "{}");
      setResult(data);
      setView("results");
    } catch (error) {
      console.error("Vibe Check failed:", error);
      alert("Something went wrong with the AI analysis. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setImage(base64String);
        performVibeCheck(base64String);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="min-h-screen max-w-md mx-auto relative overflow-hidden flex flex-col pt-safe bg-dark-bg text-white px-6">
      <AnimatePresence mode="wait">
        {view === "business_pitch" && (
          <motion.div
            key="pitch"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="flex flex-col gap-8 pb-10"
          >
            {/* Header */}
            <header className="pt-12 flex flex-col items-center gap-4 text-center">
              <div className="w-16 h-16 bg-brand rounded-xl flex items-center justify-center text-dark-bg shadow-lg shadow-brand/20">
                <Sparkles size={32} />
              </div>
              <div>
                <h1 className="text-3xl font-display font-extrabold tracking-tight gradient-text">VibeCheck AI</h1>
                <p className="text-text-dim text-xs uppercase tracking-widest font-bold mt-1">Sleek Interface v2</p>
              </div>
            </header>

            {/* Business Idea Details */}
            <div className="flex flex-col gap-6">
              <section className="gradient-card rounded-2xl p-6 border border-white/5 shadow-xl">
                <div className="bg-red-500/10 border border-red-500/20 text-red-300 px-3 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider inline-block mb-3">
                  Pain Point: Decision Fatigue
                </div>
                <h2 className="text-white font-display font-bold mb-2 flex items-center gap-2 text-lg">
                  <Smartphone className="size-5 text-brand" /> The Solution
                </h2>
                <p className="text-text-dim text-sm leading-relaxed">
                  Eliminate friction with instant, AI-validated aesthetic feedback. 
                  Providing Gen Z with the confidence they need to post, buy, and vibe.
                </p>
              </section>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-card-bg rounded-xl p-4 border border-white/5">
                  <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-brand mb-3">
                    <DollarSign size={18} />
                  </div>
                  <p className="text-[9px] text-text-dim uppercase tracking-widest font-extrabold mb-1">Monetization</p>
                  <p className="font-bold text-sm tracking-tight">Weekly Sub + Affiliate</p>
                </div>
                <div className="bg-card-bg rounded-xl p-4 border border-white/5">
                  <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-brand mb-3">
                    <Share2 size={18} />
                  </div>
                  <p className="text-[9px] text-text-dim uppercase tracking-widest font-extrabold mb-1">Growth</p>
                  <p className="font-bold text-sm tracking-tight">Viral Share Loops</p>
                </div>
              </div>

              <section className="flex flex-col gap-4">
                <h3 className="text-[10px] font-black uppercase tracking-widest text-text-dim px-2">Core Features</h3>
                <div className="grid grid-cols-1 gap-3">
                  {[
                    { label: "AI Vibe Vision", icon: <LucideImage size={14} /> },
                    { label: "Decision Engine", icon: <Zap size={14} /> },
                    { label: "Shop Integrator", icon: <Smartphone size={14} /> }
                  ].map((feat, i) => (
                    <div key={i} className="flex items-center justify-between bg-card-bg/50 border border-dashed border-border rounded-xl p-4">
                      <div className="flex items-center gap-3">
                        <div className="text-brand">{feat.icon}</div>
                        <span className="text-sm font-semibold">{feat.label}</span>
                      </div>
                      <CheckCircle2 className="text-brand size-4" />
                    </div>
                  ))}
                </div>
              </section>
            </div>

            <button 
              onClick={() => setView("demo")}
              className="mt-4 bg-brand hover:brightness-110 text-dark-bg font-extrabold py-5 rounded-xl flex items-center justify-center gap-2 transition-all active:scale-95 shadow-xl shadow-brand/10 uppercase tracking-wide text-sm"
            >
              Launch MVP Mode <ArrowRight size={18} />
            </button>
          </motion.div>
        )}

        {view === "demo" && (
          <motion.div
            key="demo"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            className="flex flex-col flex-1 pb-10 gap-6"
          >
            <div className="pt-8">
              <button onClick={() => setView("business_pitch")} className="text-text-dim hover:text-white mb-4 flex items-center gap-2 text-xs font-bold transition-colors uppercase tracking-widest">
                <X size={14} /> Exit Strategy
              </button>
              <h2 className="text-3xl font-display font-extrabold">Aesthetic Scanner</h2>
              <p className="text-text-dim text-sm mt-2">Upload a capture to extract hidden aesthetic values in 2 seconds.</p>
            </div>

            <div 
              onClick={() => !loading && fileInputRef.current?.click()}
              className="flex-1 min-h-[300px] rounded-3xl border border-dashed border-border flex flex-col items-center justify-center gap-4 bg-card-bg/20 hover:bg-card-bg/40 transition-all cursor-pointer relative overflow-hidden group vibe-card"
            >
              {loading ? (
                <div className="flex flex-col items-center gap-4">
                  <motion.div 
                    animate={{ rotate: 360 }}
                    transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
                  >
                    <RefreshCw size={48} className="text-brand" />
                  </motion.div>
                  <p className="text-brand font-black text-xs uppercase tracking-widest animate-pulse">Processing Vibe...</p>
                </div>
              ) : (
                <>
                  <div className="w-16 h-16 rounded-xl bg-brand flex items-center justify-center text-dark-bg group-hover:scale-110 transition-transform shadow-lg shadow-brand/20">
                    <Camera size={28} />
                  </div>
                  <div className="text-center">
                    <p className="font-bold text-lg">Capture Aesthetic</p>
                    <p className="text-text-dim text-[10px] uppercase font-bold tracking-tighter mt-1">92% Analysis accuracy</p>
                  </div>
                </>
              )}
            </div>

            <input 
              type="file" 
              accept="image/*" 
              className="hidden" 
              ref={fileInputRef} 
              onChange={handleImageUpload}
              disabled={loading}
            />

            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-card-bg rounded-xl border border-border flex flex-col gap-2">
                <ShieldCheck className="text-brand" size={18} />
                <p className="text-[10px] font-bold text-text-dim uppercase tracking-wide leading-tight">Secure AI Node</p>
              </div>
              <div className="p-4 bg-card-bg rounded-xl border border-border flex flex-col gap-2">
                <Zap className="text-brand" size={18} />
                <p className="text-[10px] font-bold text-text-dim uppercase tracking-wide leading-tight">Instant Payoff</p>
              </div>
            </div>
          </motion.div>
        )}

        {view === "results" && result && (
          <motion.div
            key="results"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex flex-col flex-1 pb-10 gap-8"
          >
            <div className="relative pt-12 flex justify-center">
               <motion.div 
                 initial={{ scale: 0 }}
                 animate={{ scale: 1 }}
                 transition={{ type: "spring", damping: 10 }}
                 className="absolute -top-4 px-6 h-14 rounded-xl bg-brand border border-white/20 flex items-center justify-center z-10 shadow-2xl shadow-brand/30"
               >
                  <div className="flex flex-col items-center">
                    <span className="text-dark-bg text-2xl font-black leading-none">{result.score}</span>
                    <span className="text-dark-bg/60 text-[8px] font-black uppercase tracking-tighter">Vibe Rank</span>
                  </div>
               </motion.div>
               <div className="w-full aspect-square rounded-3xl overflow-hidden border border-border shadow-2xl">
                 <img src={image!} alt="Uploaded" className="w-full h-full object-cover" />
               </div>
            </div>

            <div className="flex flex-col gap-6">
              <div className="text-center">
                <h3 className="text-text-dim text-[10px] uppercase tracking-widest font-black mb-1">Extracted Core</h3>
                <p className="text-3xl font-display font-extrabold">{result.aesthetic}</p>
              </div>

              <div className="flex flex-col gap-3">
                <h4 className="text-[10px] font-black uppercase tracking-widest text-text-dim px-2">Optimization Logic</h4>
                {result.tips.map((tip, i) => (
                  <div key={i} className="bg-card-bg/50 rounded-xl p-4 border border-border flex items-start gap-3">
                    <div className="bg-brand rounded-md size-5 flex items-center justify-center text-dark-bg text-[10px] font-black mt-0.5">{i+1}</div>
                    <p className="text-xs text-white/80 font-medium leading-relaxed">{tip}</p>
                  </div>
                ))}
              </div>

              <div className="gradient-card rounded-2xl p-6 border border-border flex flex-col gap-4 relative overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-10">
                  <TrendingUp size={80} className="text-brand" />
                </div>
                <div className="flex items-center justify-between relative z-10">
                   <div className="flex items-center gap-2 text-brand">
                     <TrendingUp size={16} />
                     <span className="text-[10px] uppercase font-black tracking-widest">Viral Engine</span>
                   </div>
                   <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-white/5 border border-white/5">
                      <LucideImage size={10} className="text-text-dim" />
                      <span className="text-[8px] font-bold text-text-dim">MATCHED SOUND</span>
                   </div>
                </div>
                <p className="text-sm font-bold leading-snug relative z-10">Recommending "{result.trendingSound}" for 8.9x viral multiplier.</p>
                <div className="h-px bg-white/5 my-1" />
                <div className="flex items-center justify-between relative z-10">
                  <div>
                    <p className="text-[9px] text-text-dim uppercase font-black tracking-widest">Affiliate Sync</p>
                    <p className="text-sm font-bold">{result.suggestedAddOn}</p>
                  </div>
                  <button className="bg-brand text-dark-bg text-[9px] font-black px-4 py-2 rounded-lg transition-transform active:scale-95 uppercase tracking-wide">
                    Buy Item
                  </button>
                </div>
              </div>
            </div>

            <div className="flex gap-4">
              <button 
                onClick={() => setView("demo")}
                className="flex-1 bg-card-bg hover:bg-white/5 text-white font-bold py-4 rounded-xl border border-border flex items-center justify-center gap-2 transition-all active:scale-95"
              >
                <RefreshCw size={16} /> Retry
              </button>
              <button 
                className="flex-1 bg-brand text-dark-bg font-extrabold py-4 rounded-xl flex items-center justify-center gap-2 transition-all active:scale-95 glow-brand uppercase text-xs tracking-wider"
                onClick={() => alert("Share Card Exported!")}
              >
                <Share2 size={16} /> Export Card
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <style>{`
        .pt-safe { padding-top: env(safe-area-inset-top); }
        .glow-brand { box-shadow: 0 0 20px rgba(255, 78, 0, 0.3); }
        @font-face {
          font-family: 'Space Grotesk';
          font-style: normal;
          font-weight: 700;
          font-display: swap;
          src: url(https://fonts.gstatic.com/s/spacegrotesk/v15/V8mDoQDj3hyHErbVE9Xit3XC_aCq7w4.woff2) format('woff2');
        }
      `}</style>
    </div>
  );
}
